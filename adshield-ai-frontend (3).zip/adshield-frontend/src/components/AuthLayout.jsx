import { motion } from "framer-motion";
import { ShieldCheck } from "lucide-react";

const NODES = Array.from({ length: 16 }, (_, i) => ({
  id: i,
  x: 10 + Math.random() * 80,
  y: 10 + Math.random() * 80,
  size: 3 + Math.random() * 4,
  delay: Math.random() * 6,
  isBot: Math.random() < 0.22,
}));

export default function AuthLayout({ eyebrow, title, subtitle, children }) {
  return (
    <div className="min-h-screen grid md:grid-cols-2 bg-ink">
      {/* Visual side — ambient trap grid, the same mechanism as the dashboard's
          Live Trap Radar, quieted down into background texture. */}
      <div className="relative hidden md:flex flex-col justify-between overflow-hidden bg-ink-soft border-r border-line-soft p-10 noise-grid">
        <div className="absolute inset-0 pointer-events-none">
          {NODES.map((n) => (
            <motion.span
              key={n.id}
              className="absolute rounded-full animate-drift"
              style={{
                left: `${n.x}%`,
                top: `${n.y}%`,
                width: n.size,
                height: n.size,
                backgroundColor: n.isBot ? "var(--color-danger)" : "var(--color-signal)",
                opacity: n.isBot ? 0.7 : 0.45,
                animationDelay: `${n.delay}s`,
                boxShadow: n.isBot ? "0 0 10px 2px rgba(255,93,108,0.5)" : "none",
              }}
            />
          ))}
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full border border-signal/20" />
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-44 h-44 rounded-full border border-signal/15" />
        </div>

        <div className="relative flex items-center gap-2">
          <ShieldCheck size={22} className="text-signal" />
          <span className="font-display font-semibold text-lg tracking-tight">AdShield AI</span>
        </div>

        <div className="relative max-w-sm">
          <p className="font-display text-3xl leading-tight text-text">
            One invisible link.<br />Every bot outs itself.
          </p>
          <p className="mt-4 text-text-muted text-sm leading-relaxed">
            Bots read raw HTML and click what they see, even the link no human can. The moment
            they do, we know — with certainty, not a guess — and your ad spend stops leaking.
          </p>
        </div>

        <p className="relative text-xs text-text-faint font-mono">FYP1 prototype — adshield.ai</p>
      </div>

      {/* Form side */}
      <div className="flex items-center justify-center p-6 sm:p-10">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-sm"
        >
          <div className="mb-8 md:hidden flex items-center gap-2">
            <ShieldCheck size={20} className="text-signal" />
            <span className="font-display font-semibold tracking-tight">AdShield AI</span>
          </div>
          {eyebrow && (
            <p className="text-xs uppercase tracking-widest text-signal font-mono mb-2">{eyebrow}</p>
          )}
          <h1 className="font-display text-2xl font-semibold text-text">{title}</h1>
          {subtitle && <p className="mt-2 text-sm text-text-muted">{subtitle}</p>}
          <div className="mt-8">{children}</div>
        </motion.div>
      </div>
    </div>
  );
}
