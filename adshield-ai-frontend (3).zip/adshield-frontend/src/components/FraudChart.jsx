import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg bg-panel-soft border border-line px-3 py-2 text-xs font-mono">
      <p className="text-text-muted mb-1">{label}</p>
      {payload.map((p) => (
        <p key={p.dataKey} style={{ color: p.color }}>
          {p.name}: {p.value}
        </p>
      ))}
    </div>
  );
}

export default function FraudChart({ data }) {
  return (
    <div className="rounded-2xl bg-panel border border-line-soft p-5 h-full flex flex-col">
      <div className="mb-3">
        <h3 className="font-display text-sm tracking-wide uppercase">Traffic Composition, 24h</h3>
        <p className="text-xs text-text-muted mt-0.5">Legit vs. suspicious vs. bot clicks, by hour</p>
      </div>
      <div className="flex-1 min-h-[220px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 4, right: 4, left: -18, bottom: 0 }}>
            <defs>
              <linearGradient id="legitFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#35E8C9" stopOpacity={0.5} />
                <stop offset="100%" stopColor="#35E8C9" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="botFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FF5D6C" stopOpacity={0.5} />
                <stop offset="100%" stopColor="#FF5D6C" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="suspFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FFB238" stopOpacity={0.5} />
                <stop offset="100%" stopColor="#FFB238" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="#1A2540" vertical={false} />
            <XAxis dataKey="hour" tick={{ fill: "#8592AD", fontSize: 11 }} axisLine={{ stroke: "#223154" }} tickLine={false} interval={3} />
            <YAxis tick={{ fill: "#8592AD", fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Area type="monotone" dataKey="legit" name="Legit" stroke="#35E8C9" fill="url(#legitFill)" strokeWidth={2} />
            <Area type="monotone" dataKey="suspicious" name="Suspicious" stroke="#FFB238" fill="url(#suspFill)" strokeWidth={2} />
            <Area type="monotone" dataKey="bots" name="Bots" stroke="#FF5D6C" fill="url(#botFill)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
