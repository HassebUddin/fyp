import { LayoutDashboard, Radar, ShieldAlert, ListTree, Settings2, ShieldCheck, LogOut } from "lucide-react";
import { useState } from "react";

const NAV = [
  { key: "overview", label: "Overview", icon: LayoutDashboard, live: true },
  { key: "traffic", label: "Traffic", icon: Radar, live: false },
  { key: "fraud", label: "Fraud Reports", icon: ShieldAlert, live: false },
  { key: "honeypot", label: "Honeypot Log", icon: ListTree, live: false },
  { key: "settings", label: "Settings", icon: Settings2, live: false },
];

export default function Sidebar({ onLogout }) {
  const [active, setActive] = useState("overview");

  return (
    <aside className="hidden md:flex w-60 shrink-0 flex-col border-r border-line-soft bg-ink-soft">
      <div className="flex items-center gap-2 px-5 h-16 border-b border-line-soft">
        <ShieldCheck size={20} className="text-signal" strokeWidth={2} />
        <span className="font-display font-semibold tracking-tight">AdShield AI</span>
      </div>

      <nav className="flex-1 py-4 px-3 space-y-1">
        {NAV.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.key;
          return (
            <button
              key={item.key}
              onClick={() => setActive(item.key)}
              className={`w-full group flex items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-sm transition-colors ${
                isActive
                  ? "bg-panel text-text border border-line-soft"
                  : "text-text-muted hover:text-text hover:bg-panel/60"
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Icon size={17} strokeWidth={1.8} />
                {item.label}
              </span>
              {!item.live && (
                <span className="text-[9px] uppercase tracking-wide text-text-faint border border-line rounded-full px-1.5 py-0.5">
                  FYP2
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-3 border-t border-line-soft">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm text-text-muted hover:text-danger hover:bg-danger/10 transition-colors"
        >
          <LogOut size={17} strokeWidth={1.8} />
          Log out
        </button>
      </div>
    </aside>
  );
}
