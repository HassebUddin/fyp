import { useEffect, useState } from "react";
import { motion } from "framer-motion";

function useCountUp(target, duration = 900) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    let start = null;
    let raf;
    function step(ts) {
      if (start === null) start = ts;
      const progress = Math.min((ts - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(Math.round(eased * target));
      if (progress < 1) raf = requestAnimationFrame(step);
    }
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return value;
}

export default function StatCard({ icon: Icon, label, value, suffix = "", tone = "signal", trend, delay = 0 }) {
  const animated = useCountUp(value);
  const toneClasses = {
    signal: "text-signal bg-signal/10",
    alert: "text-alert bg-alert/10",
    danger: "text-danger bg-danger/10",
    safe: "text-safe bg-safe/10",
  }[tone];

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, delay }}
      className="rounded-2xl bg-panel border border-line-soft p-5 hover:border-line transition-colors"
    >
      <div className="flex items-start justify-between">
        <span className={`inline-flex items-center justify-center w-9 h-9 rounded-xl ${toneClasses}`}>
          <Icon size={18} strokeWidth={1.8} />
        </span>
        {trend && (
          <span className={`text-xs font-mono ${trend.startsWith("-") ? "text-danger" : "text-safe"}`}>
            {trend}
          </span>
        )}
      </div>
      <p className="mt-4 font-mono text-3xl tracking-tight tabular-nums">
        {animated.toLocaleString()}
        <span className="text-lg text-text-muted">{suffix}</span>
      </p>
      <p className="mt-1 text-sm text-text-muted">{label}</p>
    </motion.div>
  );
}
