import { Bell, ChevronDown } from "lucide-react";

export default function Topbar({ storeName, platform }) {
  const initials = storeName
    ?.split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("") || "AS";

  return (
    <header className="h-16 border-b border-line-soft flex items-center justify-between px-5 md:px-8 bg-ink/80 backdrop-blur sticky top-0 z-10">
      <div>
        <p className="text-sm text-text-muted">Store</p>
        <button className="flex items-center gap-1.5 font-display font-medium">
          {storeName || "Your Store"}
          <ChevronDown size={15} className="text-text-muted" />
        </button>
      </div>

      <div className="flex items-center gap-4">
        <span className="hidden sm:inline-flex items-center gap-1.5 text-xs font-mono text-text-muted border border-line-soft rounded-full px-3 py-1 capitalize">
          {platform || "shopify"} connected
        </span>
        <button className="relative w-9 h-9 rounded-full border border-line-soft flex items-center justify-center text-text-muted hover:text-text transition-colors">
          <Bell size={16} strokeWidth={1.8} />
          <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-danger" />
        </button>
        <div className="w-9 h-9 rounded-full bg-signal/15 border border-signal/30 text-signal flex items-center justify-center text-xs font-semibold font-mono">
          {initials}
        </div>
      </div>
    </header>
  );
}
