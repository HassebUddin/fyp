import { motion, AnimatePresence } from "framer-motion";

const TYPE_LABEL = {
  legit: { text: "Legit", cls: "text-safe bg-safe/10 border-safe/30" },
  suspicious: { text: "Suspicious", cls: "text-alert bg-alert/10 border-alert/30" },
  bot: { text: "Bot (honeypot)", cls: "text-danger bg-danger/10 border-danger/30" },
};

const EVENT_TYPE_LABEL = {
  pageview: "Pageview",
  honeypot_hit: "Honeypot",
  session_update: "Session",
};

function timeAgo(iso) {
  const date = new Date(iso);
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 5) return "just now";
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  return `${Math.floor(seconds / 3600)}h ago`;
}

function pathFrom(url) {
  if (!url) return "—";
  try {
    const u = new URL(url);
    return u.pathname === "" ? "/" : u.pathname;
  } catch {
    return url;
  }
}

export default function TrafficFeed({ events = [], connected = false }) {
  return (
    <div className="rounded-2xl bg-panel border border-line-soft p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-display text-sm tracking-wide uppercase">Live Traffic Feed</h3>
          <p className="text-xs text-text-muted mt-0.5">Every visit, scored the moment it lands</p>
        </div>
        <span
          className={`flex items-center gap-1.5 text-xs font-mono ${connected ? "text-safe" : "text-text-faint"}`}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${connected ? "bg-safe animate-blink" : "bg-text-faint"}`} />
          {connected ? "streaming" : "connecting…"}
        </span>
      </div>

      <div className="grid grid-cols-[1fr_1fr_1fr_auto_auto] gap-2 px-2 pb-2 text-[11px] uppercase tracking-wide text-text-faint">
        <span>Page</span>
        <span className="hidden sm:block">Browser · OS</span>
        <span>IP</span>
        <span>Status</span>
        <span className="text-right">When</span>
      </div>

      {events.length === 0 ? (
        <p className="text-sm text-text-muted px-2 py-6 text-center">
          No traffic yet — paste the tracking script into your store and visit a page to see events here.
        </p>
      ) : (
        <div className="space-y-1 max-h-[280px] overflow-y-auto pr-1">
          <AnimatePresence initial={false}>
            {events.map((e, i) => {
              const label = TYPE_LABEL[e.label] || TYPE_LABEL.legit;
              const key = e.id || `${e.created_at}-${i}`;
              return (
                <motion.div
                  key={key}
                  layout
                  initial={{ opacity: 0, x: -16, height: 0 }}
                  animate={{ opacity: 1, x: 0, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.35 }}
                  className="grid grid-cols-[1fr_1fr_1fr_auto_auto] gap-2 items-center rounded-lg px-2 py-2 bg-ink-soft/60 text-sm"
                >
                  <span className="truncate" title={e.url}>
                    {EVENT_TYPE_LABEL[e.type] || e.type}
                    <span className="text-text-faint"> · {pathFrom(e.url)}</span>
                  </span>
                  <span className="hidden sm:block truncate text-text-muted">
                    {e.device?.browser || "—"} · {e.device?.os || "—"}
                  </span>
                  <span className="font-mono text-xs text-text-muted truncate">{e.ip}</span>
                  <span className={`justify-self-start text-[11px] px-2 py-0.5 rounded-full border whitespace-nowrap ${label.cls}`}>
                    {label.text}
                  </span>
                  <span className="text-right text-xs text-text-faint font-mono whitespace-nowrap">
                    {timeAgo(e.created_at)}
                  </span>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
