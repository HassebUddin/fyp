import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Users, Bot, ShieldAlert, PiggyBank } from "lucide-react";
import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";
import StatCard from "../components/StatCard";
import TrapRadar from "../components/TrapRadar";
import FraudChart from "../components/FraudChart";
import TrafficFeed from "../components/TrafficFeed";
import InstallSnippet from "../components/InstallSnippet";
import { logOut } from "../lib/api";
import { useLiveTraffic } from "../lib/useLiveTraffic";

export default function Dashboard({ session }) {
  const navigate = useNavigate();
  const { summary, events, catchSignal, connected, loadError } = useLiveTraffic();

  function handleLogout() {
    logOut();
    navigate("/login");
  }

  return (
    <div className="min-h-screen flex bg-ink">
      <Sidebar onLogout={handleLogout} />

      <div className="flex-1 min-w-0 flex flex-col">
        <Topbar storeName={session?.storeName} platform={session?.platform} />

        <main className="flex-1 p-5 md:p-8 space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <p className="text-xs uppercase tracking-widest text-signal font-mono">Overview</p>
            <h1 className="font-display text-2xl font-semibold mt-1">
              Good to see you, {session?.storeName || "there"}.
            </h1>
            <p className="text-text-muted text-sm mt-1">
              Here's what your traffic looked like over the last 24 hours.
            </p>
          </motion.div>

          {loadError && (
            <div className="rounded-xl border border-danger/30 bg-danger/10 text-danger text-sm px-4 py-3">
              Couldn't reach the backend ({loadError}). Is the Node server running and
              is <code className="font-mono">VITE_API_BASE_URL</code> pointed at it?
            </div>
          )}

          <InstallSnippet platform={session?.platform} hasTraffic={(summary.visitorsToday || 0) > 0} />

          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            <StatCard icon={Users} label="Visitors tracked today" value={summary.visitorsToday} tone="signal" delay={0.05} />
            <StatCard icon={Bot} label="Bots caught in honeypot" value={summary.botsCaught} tone="danger" delay={0.1} />
            <StatCard icon={ShieldAlert} label="Suspicious human clicks" value={summary.suspiciousClicks} tone="alert" delay={0.15} />
            <StatCard
              icon={PiggyBank}
              label="Ad budget saved (est.)"
              value={summary.budgetSavedUsd}
              suffix=" USD"
              tone="safe"
              delay={0.2}
            />
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-5 gap-5">
            <div className="xl:col-span-2 rounded-2xl bg-panel border border-line-soft p-5">
              <TrapRadar trapped={summary.botsCaught} catchSignal={catchSignal} />
            </div>
            <div className="xl:col-span-3">
              <FraudChart data={summary.series} />
            </div>
          </div>

          <TrafficFeed events={events} connected={connected} />
        </main>
      </div>
    </div>
  );
}
